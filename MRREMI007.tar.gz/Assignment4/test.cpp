#include <dirent.h>
#include <string>
#include <iostream>
#include <vector>
#include "Image.h"
#include "Pixel.h"
#include "ImageCluster.h"
#include "ImageClusterPixel.h"
#include "math.h"
#include <random>
#include <functional>
#include <algorithm>

int main()
{
    // DIR *directory;
    // dirent *file;
    // std::string fileName = "/home/emily/Documents/CSC3022F/Assignment4/Gradient_Numbers_PPMS";
    // directory = opendir(fileName.c_str());
    // while (file = readdir(directory)){
    //     std::cout << file->d_name <<std::endl;
    // }

    // MRREMI007::Image image;
    // image.readFromFile("/home/emily/Documents/CSC3022F/Assignment4/eight_1.ppm");
    // image.makeHistogram(256);

    // std::vector<MRREMI007::Pixel *> p;
    // for (int i = 0; i < 2; i++)
    // {
    //     MRREMI007::Pixel *array = new MRREMI007::Pixel[2];
    //     p.push_back(array);
    //     for (int j = 0; j < 2; j++)
    //     {
    //         unsigned char red;
    //         unsigned char blue;
    //         unsigned char green;
    //         std::cout << "enter " << i << " " << j << std::endl;
    //         std::cin >> red;
    //         std::cout << "enter " << i << " " << j << std::endl;
    //         std::cin >> green;
    //         std::cout << "enter " << i << " " << j << std::endl;
    //         std::cin >> blue;
    //         MRREMI007::Pixel pix(red, green, blue);
    //         p[i][j] = pix;
    //     }
    // }

    // for (int i = 0; i < 2; i++)
    // {
    //     for (int j = 0; j < 2; j++)
    //     {
    //         std::cout << p[i][j] << std::endl;
    //     }
    // }

    // std::vector<MRREMI007::Image> images;
    // MRREMI007::Image image("/home/emily/Documents/CSC3022F/Assignment4/eight_1.ppm", 1);
    // MRREMI007::Image image2("/home/emily/Documents/CSC3022F/Assignment4/eight_1.ppm", 2);
    // images.push_back(image);
    // std::cout << "done 1" << std::endl;
    // images.push_back(image2);
    // std::cout << "done 2" << std::endl;

    //testing images and distance and centroid creations
    /*MRREMI007::Pixel p1(1, 1, 1);
    MRREMI007::Pixel p2(2, 2, 2);
    MRREMI007::Pixel p3(3, 3, 3);
    MRREMI007::Pixel p4(65, 189, 255);

    std::vector<std::vector<MRREMI007::Pixel>> vec1;
    std::vector<MRREMI007::Pixel> first;
    first.push_back(p1);
    first.push_back(p2);
    vec1.push_back(first);
    std::vector<MRREMI007::Pixel> second;
    second.push_back(p3);
    second.push_back(p4);
    vec1.push_back(second);

    MRREMI007::Image image1;
    image1.image = vec1;
    image1.cluster = 1;
    image1.height = 2;
    image1.width = 2;
    image1.makeHistogramColour(63);

    for (auto &i : image1.histogram)
    {
        std::cout << i << " ";
    }

    std::cout << std::endl;

    std::vector<std::vector<MRREMI007::Pixel>> vec2;
    std::vector<MRREMI007::Pixel> first2;
    first2.push_back(p4);
    first2.push_back(p3);
    vec2.push_back(first2);
    std::vector<MRREMI007::Pixel> second2;
    second2.push_back(p2);
    second2.push_back(p1);
    vec2.push_back(second2);

    MRREMI007::Image image2;
    image2.image = vec2;
    image2.cluster = 1;
    image2.height = 2;
    image2.width = 2;
    image2.makeHistogramColour(63);

    std::vector<std::vector<MRREMI007::Pixel>> vec3;
    std::vector<MRREMI007::Pixel> first3;
    first3.push_back(p3);
    first3.push_back(p1);
    vec3.push_back(first3);
    std::vector<MRREMI007::Pixel> second3;
    second3.push_back(p4);
    second3.push_back(p2);
    vec3.push_back(second3);

    MRREMI007::Image image3;
    image3.image = vec3;
    image3.cluster = 0;
    image3.height = 2;
    image3.width = 2;
    image3.makeHistogramColour(63);

    
    std::vector<int> distanceTest;
    distanceTest.push_back(1);
    distanceTest.push_back(3);
    distanceTest.push_back(5);
    distanceTest.push_back(0);
    for (int i = 0; i < 4; i++)
    {
        distanceTest.push_back(i);
    }
    for (int i = 0; i < 7; i++)
    {
        distanceTest.push_back(0);
    }
    // for (auto &i : distanceTest)
    // {
    //     std::cout << i << " ";
    // }

    // std::cout << std::endl;

    MRREMI007::ImageCluster imageclus;
    // std::cout << "distance: " << imageclus.distanceColour(image1, distanceTest);
    imageclus.binSize = 63;
    imageclus.numClusters = 2;
    imageclus.images.push_back(image1);
    imageclus.images.push_back(image2);
    imageclus.images.push_back(image3);

    imageclus.centroids.push_back(distanceTest);
    imageclus.centroids.push_back(distanceTest);

    imageclus.makeCentroid(0);
    imageclus.makeCentroid(1);

    std::cout << "image cluster " << std::endl;
    for (auto &i : imageclus.centroids[1])
    {
        std::cout << i << " ";
    }
    std::cout << std::endl;*/

    // // imageclus.images[1].histogram[1] = 1;

    // // imageclus.makeCentroid(1);

    // // for (auto &i : imageclus.centroids[1])
    // // {
    // //     std::cout << i << " ";
    // // }
    // // std::cout << std::endl;

    // for (auto &i : imageclus.images)
    // {
    //     i.cluster = 5;
    // }
    // std::cout << imageclus.images[0].cluster;

    // // float total{};
    // // for (int i = 0; i < first.size(); i++)
    // // {
    // //     total += std::pow(first[i] - second[i], 2);
    // // }
    // // float distance = std::sqrt(total);
    // // std::cout << distance;

    //testing random
    /*std::default_random_engine ranEngine;
    std::uniform_int_distribution<int> ranGenerator(1, 100);
    auto randCluster = std::bind(ranGenerator, ranEngine);
    for (int i = 0; i < 10; i++)
    {
        std::cout << randCluster() << std::endl;
    }

    std::cout << "testing rand" << std::endl;
    for (int i = 0; i < 10; i++)
    {
        std::cout << rand() % 100 << std::endl;
    }*/

    /*std::vector<int> randomClusters;
    std::srand(time(NULL));
    int images = 10;
    int numClusters = 11;
    while (randomClusters.size() < numClusters)
    {
        int i = rand() % images;
        //check if the number of clusters is less than the number of images, else must allow duplicates
        if (randomClusters.size() < images)
        {
            if (std::find(randomClusters.begin(), randomClusters.end(), i) == randomClusters.end())
            {
                randomClusters.push_back(i);
            }
        }
        else
        {
            randomClusters.push_back(i);
        }
    }
    for (auto& i: randomClusters){
        std::cout << i << " ";
    }*/

    //testing image clustering
    // MRREMI007::ImageClusterPixel imagePixel("/home/emily/Documents/CSC3022F/Assignment4/Gradient_Numbers_PPMS", 10);
    MRREMI007::ImageCluster imagePixel("/home/emily/Documents/CSC3022F/Assignment4/Gradient_Numbers_PPMS", 10, 64, true);
    std::cout << imagePixel;

    return 0;
}